import * as universal from "../../../src/routes/play/[userInput]/+page.js";
export { universal };
export { default as component } from "../../../src/routes/play/[userInput]/+page.svelte";