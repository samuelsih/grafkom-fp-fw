export const load = ({ params }) => {
    return {
        tilesAmount: params.userInput
    }
}